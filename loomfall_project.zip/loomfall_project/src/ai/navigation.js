export class Navigation {}
