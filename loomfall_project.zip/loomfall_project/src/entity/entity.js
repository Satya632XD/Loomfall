export class Entity {
  constructor() {
    this.position = { x: 0, y: 0, z: 0 };
  }
}
