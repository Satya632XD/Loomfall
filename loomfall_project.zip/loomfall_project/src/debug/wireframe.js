export class Wireframe {}
